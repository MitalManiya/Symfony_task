<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* gallery.html.twig */
class __TwigTemplate_45046ecb4d43a7fb6cdfb0a0bbdc1f96e36d967e7309c36c9612454ba98d44ab extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'head_css' => [$this, 'block_head_css'],
            'head_js' => [$this, 'block_head_js'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "gallery.html.twig"));

        // line 1
        echo "

\t<!DOCTYPE html>
\t<html>
\t<head>
\t\t<meta charset=\"UTF-8\">
\t\t<title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
\t\t";
        // line 8
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 9
        echo "\t</head>
\t";
        // line 11
        echo "
\t";
        // line 13
        echo "\t";
        $this->displayBlock('head_css', $context, $blocks);
        // line 17
        echo "\t";
        $this->displayBlock('head_js', $context, $blocks);
        // line 26
        echo "
\t<html>
\t<style>
\t\timg {max-height:125px; margin:3px; border:1px solid #dedede;}
\t</style>
\t<body>

\t<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>


\t<script>

\t\tvar settings = {
\t\t\t\"async\": true,
\t\t\t\"crossDomain\": true,
\t\t\t\"url\": \"https://api.flickr.com/services/rest/?method=flickr.galleries.getPhotos&api_key=aebc4f23c65b7f70c39f8aa7cebafff1&gallery_id=66911286-72157647277042064&format=json&nojsoncallback=1\",
\t\t\t\"method\": \"GET\",
\t\t\t\"headers\": {}
\t\t}

\t\t\$.ajax(settings).done(function (data) {
\t\t\tconsole.log(data);



\t\t\t\$(\"#galleryTitle\").append(data.photos.photo[0].title + \" Gallery\");
\t\t\t\$.each( data.photos.photo, function( i, gp ) {

\t\t\t\tvar farmId = gp.farm;
\t\t\t\tvar serverId = gp.server;
\t\t\t\tvar id = gp.id;
\t\t\t\tvar secret = gp.secret;

\t\t\t\tconsole.log(farmId + \", \" + serverId + \", \" + id + \", \" + secret);

//  https://farm{farm-id}.staticflickr.com/{server-id}/{id}_{secret}.jpg

\t\t\t\t\$(\"#flickr\").append('<img src=\"https://farm' + farmId + '.staticflickr.com/' + serverId + '/' + id + '_' + secret + '.jpg\"/>');

\t\t\t});
\t\t});

\t</script>


\t<h2><div id=\"galleryTitle\"></div></h2>
\t<div style=\"clear:both;\"/>
\t<div id=\"flickr\"/>


\t</body>
\t</html>


";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 7
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 8
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 13
    public function block_head_css($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head_css"));

        // line 14
        echo "\t\t<!-- Copy CSS from https://getbootstrap.com/docs/4.4/getting-started/introduction/#css -->
\t\t<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css\" integrity=\"sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh\" crossorigin=\"anonymous\">
\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 17
    public function block_head_js($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head_js"));

        // line 18
        echo "\t\t<!-- Copy JavaScript from https://getbootstrap.com/docs/4.4/getting-started/introduction/#js -->
\t\t<script src=\"https://code.jquery.com/jquery-3.4.1.slim.min.js\" integrity=\"sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n\" crossorigin=\"anonymous\"></script>
\t\t<script src=\"https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js\" integrity=\"sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo\" crossorigin=\"anonymous\"></script>
\t\t<script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js\" integrity=\"sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6\" crossorigin=\"anonymous\"></script>

\t\t<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js\"></script>
";
        // line 25
        echo "\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "gallery.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  187 => 25,  179 => 18,  172 => 17,  163 => 14,  156 => 13,  144 => 8,  131 => 7,  70 => 26,  67 => 17,  64 => 13,  61 => 11,  58 => 9,  56 => 8,  52 => 7,  44 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("

\t<!DOCTYPE html>
\t<html>
\t<head>
\t\t<meta charset=\"UTF-8\">
\t\t<title>{% block title %}Welcome!{% endblock %}</title>
\t\t{% block stylesheets %}{% endblock %}
\t</head>
\t{# templates/base.html.twig #}

\t{# beware that the blocks in your template may be named different #}
\t{% block head_css %}
\t\t<!-- Copy CSS from https://getbootstrap.com/docs/4.4/getting-started/introduction/#css -->
\t\t<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css\" integrity=\"sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh\" crossorigin=\"anonymous\">
\t{% endblock %}
\t{% block head_js %}
\t\t<!-- Copy JavaScript from https://getbootstrap.com/docs/4.4/getting-started/introduction/#js -->
\t\t<script src=\"https://code.jquery.com/jquery-3.4.1.slim.min.js\" integrity=\"sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n\" crossorigin=\"anonymous\"></script>
\t\t<script src=\"https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js\" integrity=\"sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo\" crossorigin=\"anonymous\"></script>
\t\t<script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js\" integrity=\"sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6\" crossorigin=\"anonymous\"></script>

\t\t<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js\"></script>
{#\t\t<script src=\"assets/js/gallery.js\"></script>#}
\t{% endblock %}

\t<html>
\t<style>
\t\timg {max-height:125px; margin:3px; border:1px solid #dedede;}
\t</style>
\t<body>

\t<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>


\t<script>

\t\tvar settings = {
\t\t\t\"async\": true,
\t\t\t\"crossDomain\": true,
\t\t\t\"url\": \"https://api.flickr.com/services/rest/?method=flickr.galleries.getPhotos&api_key=aebc4f23c65b7f70c39f8aa7cebafff1&gallery_id=66911286-72157647277042064&format=json&nojsoncallback=1\",
\t\t\t\"method\": \"GET\",
\t\t\t\"headers\": {}
\t\t}

\t\t\$.ajax(settings).done(function (data) {
\t\t\tconsole.log(data);



\t\t\t\$(\"#galleryTitle\").append(data.photos.photo[0].title + \" Gallery\");
\t\t\t\$.each( data.photos.photo, function( i, gp ) {

\t\t\t\tvar farmId = gp.farm;
\t\t\t\tvar serverId = gp.server;
\t\t\t\tvar id = gp.id;
\t\t\t\tvar secret = gp.secret;

\t\t\t\tconsole.log(farmId + \", \" + serverId + \", \" + id + \", \" + secret);

//  https://farm{farm-id}.staticflickr.com/{server-id}/{id}_{secret}.jpg

\t\t\t\t\$(\"#flickr\").append('<img src=\"https://farm' + farmId + '.staticflickr.com/' + serverId + '/' + id + '_' + secret + '.jpg\"/>');

\t\t\t});
\t\t});

\t</script>


\t<h2><div id=\"galleryTitle\"></div></h2>
\t<div style=\"clear:both;\"/>
\t<div id=\"flickr\"/>


\t</body>
\t</html>


", "gallery.html.twig", "C:\\wamp64\\www\\flickr_gallery\\templates\\gallery.html.twig");
    }
}
