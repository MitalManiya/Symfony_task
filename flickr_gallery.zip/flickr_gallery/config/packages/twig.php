// config/packages/twig.php
$container->loadFromExtension('twig', [
    'form_themes' => [
        'gallery.html.twig',
    ],

    // ...
]);